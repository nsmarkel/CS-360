package com.zybooks.markeloption2;


import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class SMSConsent extends AppCompatActivity {
    Button SMS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);
        SMS=findViewById(R.id.SMSConsent);
        // On click event on button
        SMS.setOnClickListener(v -> showSimpleDialog());
    }

    private void showSimpleDialog(){
        AlertDialog.Builder builder;
        builder = new AlertDialog.Builder(this);
        builder.setMessage("Do you want to get texts?");

        //Setting message manually and performing action on button click
        builder.setMessage("Do you want to get texts?")
                .setCancelable(false)
                .setPositiveButton("Yes", (dialog, id) -> {
                    //  Action for 'Yes' Button
                    //exit application
                    finish();
                    System.exit(0);
                })
                .setNegativeButton("No", (dialog, id) -> {
                    //  Action for 'No' Button
                    Toast.makeText(getApplicationContext(),"Cancel",Toast.LENGTH_SHORT).show();
                });
        //Creating dialog box
        AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("Message Title");
        alert.show();
    }
}
