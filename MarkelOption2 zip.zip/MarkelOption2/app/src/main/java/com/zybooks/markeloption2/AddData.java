 package com.zybooks.markeloption2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

 public class AddData extends AppCompatActivity {

     EditText subject, description;
     Button add, SMS, delete;
     DataDB DB;

//             When add button is pressed, this adds the data from the entry into the database
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);

        subject =  (EditText) findViewById(R.id.textView2);
        description =  (EditText) findViewById(R.id.textView3);



        add = (Button) findViewById(R.id.button);
        SMS = (Button) findViewById(R.id.SMSConsent);
        delete = (Button) findViewById(R.id.delete);

        DB = new DataDB(this);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sub = subject.getText().toString();
                String des = description.getText().toString();

                DB.insertData(sub, des);

                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        SMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SMSConsent.class);
                startActivity(intent);
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sub = subject.getText().toString();
                String des = description.getText().toString();

                DB.deleteData(sub, des);

                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });


    }
}