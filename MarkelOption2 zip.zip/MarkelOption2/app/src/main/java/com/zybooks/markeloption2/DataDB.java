package com.zybooks.markeloption2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

public class DataDB extends SQLiteOpenHelper{
    public static final String DBNAME = "Data.db";

    public DataDB(Context context) {
        super(context, "login.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB){
        MyDB.execSQL("create Table reminders(subject TEXT primary key, description TEXT)");
    }

    @Override
    public  void onUpgrade(SQLiteDatabase MyDB, int i, int i1){
        MyDB.execSQL("drop Table if exists reminders");
    }

    public Boolean insertData(String subject, String description){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("subject", subject);
        contentValues.put("description", description);
        long result = MyDB.insert("subject", null, contentValues);
        if(result == 1) return false;
        else
            return true;
    }

    public Boolean deleteData(String subject, String description){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.remove(subject);
        contentValues.remove(description);
        return true;
    }
}
